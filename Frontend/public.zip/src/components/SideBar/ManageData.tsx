import { Button } from "@/components/ui/button";
import { FC, useState, useEffect } from "react";
import { AddPlacementDataDialog } from "./CoOrdinatorComponent/AddPlacementDataDialog";
import { Link } from "react-router-dom";
import { FileSpreadsheet } from "lucide-react";
interface ManageData {
  activePage: string;
  user: {
    user_id: number | null; // Unique ID of the user
    first_name: string | null; // First name of the user
    last_name: string | null; // Last name of the user
    email: string | null; // Email of the user
    username: string | null; // Username of the user
    type_id: number | null; // Type ID of the user (e.g., role)
    institute_id: number | null; // ID of the associated institute
    is_active: boolean;
  }; // Active status of the user
}

export const ManageData: FC<ManageData> = ({ user, activePage }) => {
  return (
    <div className="flex flex-col space-y-4">
      <Link
        to="/admin/add-finance"
        className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-all hover:text-primary ${
          activePage === "add-finance"
            ? "bg-muted text-primary"
            : "text-muted-foreground"
        }`}
      >
        <FileSpreadsheet className="h-4 w-4" />
        Finance
      </Link>

      {/* Add Placement Data Dialog */}
      <AddPlacementDataDialog user={user} />
    </div>
  );
};

export default ManageData;
