import { FC, useState, useEffect } from "react";
import { SidebarHeader } from "./SidebarHeader";
import { SidebarNavigation } from "./SidebarNavigation";
import { AddDataDialog } from "./AddDataDialog";
import { ProfileSection } from "./ProfileSection";
import { Link } from "react-router-dom";
import { EnrollCourses } from "./EnrollCourses";
import { Home, FileInput, FileSpreadsheet, Layout } from "lucide-react";
import { ManageData } from "./ManageData";

interface SidebarProps {
  activePage: string;
  user: {
    userid: number | null;
    email: string | null;
    username: string | null;
    institute_id: number | null;
    type_id: number | null;
  } | null;
}

export const Sidebar: FC<SidebarProps> = ({ activePage, user }) => {
  const [hasPrograms, setHasPrograms] = useState(false);

  useEffect(() => {
    const checkPrograms = async () => {
      if (user?.institute_id) {
        try {
          const response = await fetch(`/get-programs/${user.institute_id}`);
          const data = await response.json();
          setHasPrograms(data.programs && data.programs.length > 0);
        } catch (error) {
          console.error("Error checking programs:", error);
        }
      }
    };

    checkPrograms();
  }, [user?.institute_id]);

  return (
    <div className="hidden border-r bg-muted/40 md:block w-[230px]">
      <div className="flex flex-col gap-2">
        <SidebarHeader user={user} activePage="add-finance" />

        <nav className="flex-1 grid items-start px-2 text-sm font-medium lg:px-4">
          {/* Add Data Dialog for Faculty (type_id = 3) */}
          {/* Dashboard Link  */}
          <Link
            to={`/dashboard/${user?.username}`}
            className={`mt-4 flex items-center gap-3 rounded-lg px-3 py-2 transition-all hover:text-primary ${
              activePage === "dashboard"
                ? "bg-muted text-primary"
                : "text-muted-foreground"
            }`}
          >
            <Home className="h-4 w-4" />
            Dashboard
          </Link>

          {/* Conditional Rendering for Admin (type_id = 1) */}
          {user?.type_id === 1 && (
            <>
              {/* Manage/Create Institute Links */}
              {user?.institute_id === null ? (
                <Link
                  to="/admin/create-institute"
                  className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-all hover:text-primary ${
                    activePage === "create-institute"
                      ? "bg-muted text-primary"
                      : "text-muted-foreground"
                  }`}
                >
                  <FileInput className="h-4 w-4" />
                  Create Institute
                </Link>
              ) : (
                <>
                  <Link
                    to="/admin/manage-institute"
                    className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-all hover:text-primary ${
                      activePage === "manage-institute"
                        ? "bg-muted text-primary"
                        : "text-muted-foreground"
                    }`}
                  >
                    <FileInput className="h-4 w-4" />
                    Manage Institute
                  </Link>
                  {hasPrograms && (
                    <Link
                      to="/admin/manage-programs"
                      className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-all hover:text-primary ${
                        activePage === "manage-programs"
                          ? "bg-muted text-primary"
                          : "text-muted-foreground"
                      }`}
                    >
                      <FileSpreadsheet className="h-4 w-4" />
                      Manage Programs
                    </Link>
                  )}
                  <Link
                    to="/admin/create-department"
                    className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-all hover:text-primary ${
                      activePage === "create-department"
                        ? "bg-muted text-primary"
                        : " text-muted-foreground"
                    }`}
                  >
                    <Layout className="h-4 w-4" />
                    Departments
                  </Link>
                  <Link
                    to="/admin/create-event"
                    className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-all hover:text-primary ${
                      activePage === "create-event"
                        ? "bg-muted text-primary"
                        : "text-muted-foreground"
                    }`}
                  >
                    <FileSpreadsheet className="h-4 w-4" />
                    Events
                  </Link>

                  <Link
                    to="/admin/add-research"
                    className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-all hover:text-primary ${
                      activePage === "create-research"
                        ? "bg-muted text-primary"
                        : "text-muted-foreground"
                    }`}
                  >
                    <FileSpreadsheet className="h-4 w-4" />
                    Research
                  </Link>
                  <Link
                    to="/admin/add-opportunity"
                    className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-all hover:text-primary ${
                      activePage === "create-opportunity"
                        ? "bg-muted text-primary"
                        : "text-muted-foreground"
                    }`}
                  >
                    <FileSpreadsheet className="h-4 w-4" />
                    Opportunity
                  </Link>
                  <Link
                    to="/admin/create-infrastructure"
                    className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-all hover:text-primary ${
                      activePage === "create-infrastructure"
                        ? "bg-muted text-primary"
                        : "text-muted-foreground"
                    }`}
                  >
                    <FileSpreadsheet className="h-4 w-4" />
                    Infrastructure
                  </Link>
                </>
              )}
            </>
          )}

          {/* user type 2 ---cordinator thing */}
          {/* method 1 */}
          {/* {user?.type_id === 2 && (
            <>
             
                  
                  <Link
                    to="/admin/create-infrastructure"
                    className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-all hover:text-primary ${
                      activePage === "create-infrastructure" ? "bg-muted text-primary" : "text-muted-foreground"
                    }`}
                  >
                    <FileSpreadsheet className="h-4 w-4" />
                    Manage Data
                  </Link>




              
              
            </>
          )} */}

          {/* method 2 */}
          {user?.type_id === 2 && <ManageData user={user} />}

          {/* {user?.type_id === 3 && <AddDataDialog user={user} />} */}
          {user?.type_id === 3 && (
            <>
              {/* Add Data Dialog */}
              <AddDataDialog user={user} />

              {/* Feedback Link */}
              <Link
                to="/faculty/feedback"
                className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-all hover:text-primary ${
                  activePage === "faculty-feedback"
                    ? "bg-muted text-primary"
                    : "text-muted-foreground"
                }`}
              >
                <FileInput className="h-4 w-4" />
                Give Feedback
              </Link>
            </>
          )}

          {/* Additional Links for Other User Types can be added here */}
          {user?.type_id === 4 && <EnrollCourses user={user} />}
        </nav>
        <div className="mt-auto pl-0 p-2 ">
          <ProfileSection user={user} />
        </div>
      </div>
    </div>
  );
};
