import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { Accordion_styles } from './components/Accordion_styles';
import {Page} from './components/AuthenticationPage'
import { Dashboard } from './components/Dashboard';
import { ThemeProvider } from "@/components/theme-provider"
import { CreateInstitute } from './components/CreateInstitute';
import { CreateProgram } from './components/CreateProgram';
import { CreateDepartment } from './components/CreateDepartment';
import { CreateCourse } from './components/CreateCourse';
import { ManageInstitute } from './components/ManageInstitute';
import { SignUpFormFaculty } from './components/SignUpFormFaculty';
import { CreateEvent } from './components/CreateEvent';
import { SignUpFormAdmin } from "./components/SignUpFormAdmin";
import { FileUpload } from "./components/addStudentData";
import {FacultyRegistration} from './components/FacultyRegistrationForm'
import { AddDataDialog } from './components/SideBar/AddDataDialog';
import {FacultyFeedback} from './components/FacultyFeedback'
import { ToastContainer } from 'react-toastify';
import { SignUpFormStudent } from './components/SignUpFormStudent';
import { CreateResearch } from "./components/CreateResearch";
import { CreateOpportunity } from './components/CreateOpportunity';
import { CreateInfrastructure } from './components/CreateInfrastructure';
import { CreateFinance } from './components/CreateFinance';
const App: React.FC = () => {
  return (
    <>
    <ThemeProvider defaultTheme="light" storageKey="vite-ui-theme">
    <Router>
        <Routes>
          <Route path="/" element={<Accordion_styles />} />
          <Route path="/dashboard/:username" element={<Dashboard/>}/>
          <Route path="/admin/create-institute" element={<CreateInstitute/>} />
          <Route path="/admin/manage-institute" element={<ManageInstitute/>} />
          <Route path="/admin/create-program" element={<CreateProgram/>} />
          <Route path="/admin/create-department" element={<CreateDepartment/>} />
          <Route path="/instructor/create-course" element={<CreateCourse/>} />
          <Route path="/faculty/feedback" element={  <FacultyFeedback/> } />
          <Route path="/login" element={<Page/>} />
          <Route path="/admin/create-event" element={<CreateEvent/>} />
          <Route path="/" element={<Accordion_styles />} />
          <Route path="/dashboard/:username" element={<Dashboard />} />
          <Route path="/admin/create-institute" element={<CreateInstitute />} />
          <Route path="/login" element={<Page />} />
          <Route path="/signup/faculty" element={< FacultyRegistration/>} />
          <Route path="/signup/institueAdmin" element={<SignUpFormAdmin />} />
          <Route path="/signup/student" element={<SignUpFormStudent />} />
          <Route path="/faculty/addData" element={<FileUpload />} />
          <Route path="/admin/add-research" element={<CreateResearch/>} />
          <Route path="/admin/add-opportunity" element={<CreateOpportunity/>} />
          <Route path="/admin/create-infrastructure" element={<CreateInfrastructure/>} />
          <Route path="/admin/add-finance" element={<CreateFinance/>} />




        </Routes>
        <ToastContainer /> 
      </Router>
    </ThemeProvider>
    </>
  );
};

export default App;